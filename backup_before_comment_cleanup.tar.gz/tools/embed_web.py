"""
Packt die Web-Oberfläche (web/index.html) und die Haltestellenliste (web/stops.txt)
gzip-komprimiert in src/generated/web_assets.h.

Läuft automatisch vor jedem PlatformIO-Build (extra_scripts = pre:tools/embed_web.py),
kann aber auch direkt gestartet werden:  python3 tools/embed_web.py
"""
import gzip
import io
import os

ASSETS = [
    ("index_html", "web/index.html"),
    ("stops_txt", "web/stops.txt"),
]


def gz(data: bytes) -> bytes:
    buf = io.BytesIO()
    # mtime=0 -> reproduzierbar, Header ändert sich nur wenn sich der Inhalt ändert
    with gzip.GzipFile(fileobj=buf, mode="wb", compresslevel=9, mtime=0) as f:
        f.write(data)
    return buf.getvalue()


def generate(project_dir: str) -> None:
    out_path = os.path.join(project_dir, "src", "generated", "web_assets.h")
    lines = [
        "// AUTOMATISCH ERZEUGT von tools/embed_web.py - nicht von Hand bearbeiten!",
        "#pragma once",
        "#include <stdint.h>",
        "#include <stddef.h>",
        "",
    ]
    for name, rel in ASSETS:
        with open(os.path.join(project_dir, rel), "rb") as f:
            raw = f.read()
        data = gz(raw)
        lines.append(f"// {rel}: {len(raw)} Bytes -> {len(data)} Bytes gzip")
        lines.append(f"static const uint8_t {name}_gz[] = {{")
        for i in range(0, len(data), 20):
            lines.append("  " + ",".join(str(b) for b in data[i:i + 20]) + ",")
        lines.append("};")
        lines.append(f"static const size_t {name}_gz_len = {len(data)};")
        lines.append("")
    content = "\n".join(lines)

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    old = None
    if os.path.exists(out_path):
        with open(out_path, "r", encoding="utf-8") as f:
            old = f.read()
    if old != content:
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(content)
        print("embed_web: web_assets.h aktualisiert")


try:
    Import("env")  # noqa: F821  (nur unter PlatformIO/SCons vorhanden)
    generate(env.subst("$PROJECT_DIR"))  # noqa: F821
except NameError:
    if __name__ == "__main__":
        generate(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
