#ifndef HTTP_JSON_H
#define HTTP_JSON_H

#include <Arduino.h>
#include <ArduinoJson.h>

namespace http {

// Lädt eine URL (HTTPS) und parst JSON direkt aus dem Stream (kein großer Puffer).
// skipToBrace: Antwort beginnt mit JS-Präfix (z.B. "journeysObj = {...}" bei ÖBB)
// filter: optionaler ArduinoJson-Filter (nullptr = alles)
bool getJson(const String &url, JsonDocument &doc, JsonDocument *filter, bool skipToBrace, String &error);

// URL-Encoding für Query-Parameter
String urlEncode(const String &s);

} // namespace http

#endif
