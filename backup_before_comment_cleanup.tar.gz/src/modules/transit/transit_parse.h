#ifndef TRANSIT_PARSE_H
#define TRANSIT_PARSE_H

#include <ArduinoJson.h>
#include "transit_types.h"

// ---------------------------------------------------------------------------
// Parser für Wiener Linien OGD-Realtime und ÖBB Scotty-Liveticker.
// Kein WiFi/HTTP hier drin -> am PC mit Beispieldaten testbar.
// ---------------------------------------------------------------------------
namespace transit {

// Row mit Defaults aus der Konfiguration befüllen (vor dem ersten Abruf)
void initRow(Row &row, const MonitorConfig &cfg);

// --- Wiener Linien ---------------------------------------------------------
// Filter reduziert die Antwort (~15 KB) auf das Nötigste
void buildWlFilter(JsonDocument &filter);
// Befüllt rows[i] für alle cfgs[i] mit src == WL. Gibt Anzahl gefundener Linien zurück.
int parseWl(JsonDocument &doc, const MonitorConfig *cfgs, size_t n, Row *rows, time_t now);
VehicleKind kindFromWlType(const char *type, const char *line);

// --- ÖBB -------------------------------------------------------------------
void buildOebbFilter(JsonDocument &filter);
bool parseOebb(JsonDocument &doc, const MonitorConfig &cfg, Row &row, time_t now);
// "S 45" -> "S45" / SBahn, "Bus 35A" -> "35A" / Bus, "RJX 766" -> "RJX" / Train
VehicleKind parseOebbProduct(const char *pr, char *lineOut, size_t n);

} // namespace transit

#endif
