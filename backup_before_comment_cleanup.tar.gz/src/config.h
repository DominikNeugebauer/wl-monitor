#ifndef APP_CONFIG_H
#define APP_CONFIG_H

// ---------------------------------------------------------------------------
// Hardware (ESP32-S3 N16R8 + 1.8" ST7735 160x128)
// ---------------------------------------------------------------------------
#define TFT_MOSI  8   // IO8
#define TFT_SCLK  9   // IO9
#define TFT_CS    10  // IO10
#define TFT_DC    11  // IO11 (DS/RS)
#define TFT_RST   12  // IO12
#define TFT_BL    13  // IO13 (Backlight, PWM)
#define LED_PIN   35  // IO35 (Info LED)
#define BTN_PIN   0   // BOOT-Taster: 5 s halten = WLAN-Daten löschen

// Falls Farben vertauscht/verschoben sind: INITR_GREENTAB / INITR_REDTAB probieren
#define TFT_INIT_TAB INITR_BLACKTAB

// 0 = Software-SPI (wie im ursprünglichen Code, sicher funktionierend)
// 1 = Hardware-SPI (schneller, zum Ausprobieren)
#define TFT_USE_HW_SPI 0

// ---------------------------------------------------------------------------
// Netzwerk
// ---------------------------------------------------------------------------
#define APP_HOSTNAME        "wl-monitor"        // -> http://wl-monitor.local
#define AP_SSID_PREFIX      "WL-Monitor-"       // + 4 Hex-Zeichen der MAC
#define AP_PASSWORD         "fahrplan"          // min. 8 Zeichen, "" = offenes WLAN
#define STA_CONNECT_TIMEOUT_MS  20000UL         // so lange pro Verbindungsversuch
#define STA_RETRY_INTERVAL_MS   30000UL         // Wiederholung wenn WLAN weg ist
#define AP_FALLBACK_AFTER_MS    90000UL         // so lange ohne WLAN -> Setup-AP wieder an
#define AP_LINGER_MS           120000UL         // AP nach erfolgreicher Einrichtung noch offen lassen

#define NTP_SERVER_1 "pool.ntp.org"
#define NTP_SERVER_2 "time.cloudflare.com"

// ---------------------------------------------------------------------------
// Abfahrten
// ---------------------------------------------------------------------------
#define FETCH_INTERVAL_MS 60000UL   // jede Minute neu laden
#define OEBB_MAX_JOURNEYS 12        // so viele Züge pro ÖBB-Abfrage
// Fallback: sind die Wiener Linien nicht erreichbar (z.B. manche Magenta-Anschlüsse),
// kommen die WL-Zeilen von der ÖBB-Auskunft. WL wird dann nur alle 5 min erneut probiert.
#define WL_RETRY_INTERVAL_MS      300000UL
#define FALLBACK_RESOLVE_RETRY_MS 600000UL  // ÖBB-Station nicht gefunden -> erst nach 10 min wieder suchen

#define FW_VERSION "1.0.0"

#endif
