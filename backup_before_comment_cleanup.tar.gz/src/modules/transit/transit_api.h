#ifndef TRANSIT_API_H
#define TRANSIT_API_H

#include <Arduino.h>
#include <ArduinoJson.h>
#include "transit_types.h"

// ---------------------------------------------------------------------------
// Online-Abfragen (Wiener Linien OGD Realtime + ÖBB Scotty)
// ---------------------------------------------------------------------------
namespace transit {

// alle WL-Einträge mit EINER Anfrage (stopId=..&stopId=..)
bool fetchWl(const MonitorConfig *cfgs, size_t n, Row *rows, time_t now, String &error);
// ein ÖBB-Eintrag (Station + optional Richtung)
bool fetchOebb(const MonitorConfig &cfg, Row &row, time_t now, String &error);

// --- für die Web-Oberfläche ---
// alle Linien/Richtungen einer WL-Station (DIVA) -> [{rbl,line,towards,type}]
bool wlLookup(uint32_t diva, JsonArray out, String &error);
// ÖBB-Stationssuche -> [{id,name}]
bool oebbSearch(const String &query, JsonArray out, String &error);
// ÖBB-Abfahrtstafel -> eindeutige [{line,dest,kind}]
bool oebbLines(uint32_t eva, JsonArray out, String &error);

// --- Fallback: WL-Linien über die ÖBB-Auskunft, wenn wienerlinien.at nicht erreichbar ist ---
// sucht die ÖBB-Station zu einem WL-Haltestellennamen, an der die Linie auch fährt
bool oebbFindStopForLine(const char *wlStopName, const char *line, uint32_t &eva, String &error);
// Abfahrten einer WL-Linie aus der ÖBB-Tafel (destKey = Ziel-Suchwort, "" = alle Richtungen)
bool fetchOebbFallback(const MonitorConfig &wlCfg, uint32_t eva, const char *destKey, Row &row,
                       time_t now, String &error);

const char *kindName(VehicleKind k);

} // namespace transit

#endif
