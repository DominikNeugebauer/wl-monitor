#ifndef TRANSIT_SERVICE_H
#define TRANSIT_SERVICE_H

#include <Arduino.h>
#include "transit_types.h"

// ---------------------------------------------------------------------------
// Holt im Hintergrund (eigener FreeRTOS-Task) jede Minute alle Abfahrten.
// Das Display liest nur Snapshots -> UI bleibt flüssig während HTTPS läuft.
// ---------------------------------------------------------------------------
class TransitService {
public:
    void begin();
    void setConfig(const MonitorConfig *cfgs, uint8_t n); // kopiert + lädt sofort neu
    void requestRefresh();

    // Kopie der aktuellen Zeilen, gibt Anzahl zurück
    size_t snapshot(Row *out, size_t max);

    bool     fetching() const { return _fetching; }
    bool     lastError() const { return _lastError; }
    String   lastErrorText();
    uint32_t lastFetchMs() const { return _lastFetchMs; }
    float    progress() const; // 0..1 bis zum nächsten Abruf
    bool     fallbackActive() const { return _fallbackActive; } // WL-Zeilen kommen gerade von der ÖBB

private:
    static void taskEntry(void *arg);
    void run();
    void fetchAll();

    SemaphoreHandle_t _mtx = nullptr;
    TaskHandle_t      _task = nullptr;
    MonitorConfig     _cfg[kMaxMonitors];
    Row               _rows[kMaxMonitors];
    uint8_t           _n = 0;
    uint32_t          _cfgVersion = 0;
    volatile bool     _fetching = false;
    volatile bool     _lastError = false;
    volatile uint32_t _lastFetchMs = 0;
    String            _errText;

    // --- ÖBB-Fallback für WL-Zeilen (nur im Task benutzt) ---
    void fetchWlViaOebb(const MonitorConfig *cfg, Row *rows, uint8_t n, time_t now,
                        bool &anyError, String &errText);
    uint32_t          _fbVersion = 0xFFFFFFFF;          // für welche Konfiguration gelten die Daten
    uint32_t          _fbEva[kMaxMonitors];             // gefundene ÖBB-Station je Zeile (0 = unbekannt)
    uint32_t          _fbTriedMs[kMaxMonitors];         // letzter erfolgloser Suchversuch
    char              _learnedDest[kMaxMonitors][24];   // Ziel aus der letzten WL-Antwort
    uint32_t          _wlRetryAt = 0;                   // vorher WL nicht erneut probieren
    bool              _wlBackoff = false;
    volatile bool     _fallbackActive = false;
};

#endif
