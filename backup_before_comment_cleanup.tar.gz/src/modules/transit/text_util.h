#ifndef TEXT_UTIL_H
#define TEXT_UTIL_H

#include <stddef.h>
#include <stdint.h>

namespace text {

// sicheres strncpy (immer 0-terminiert)
void copy(char *dst, size_t n, const char *src);

// "S 45" -> "S45", "35a" -> "35A"
void normalizeLine(const char *in, char *out, size_t n);
bool lineEquals(const char *a, const char *b);

// ÖBB liefert ISO-8859-1 + HTML-Entities (&#252;) + teils <b>-Tags -> sauberes UTF-8
void oebbToUtf8(const char *in, char *out, size_t n);

// "Wien Hütteldorf Bahnhof" -> "Hütteldorf", "Schottentor U" -> "Schottentor"
void cleanStationName(char *s);

// case-insensitiver "enthält"-Vergleich, Umlaute/ß werden gefaltet (ü==ue, ß==ss)
bool containsFolded(const char *hay, const char *needle);

// längstes Wort eines Namens ("Bhf. Heiligenstadt" -> "Heiligenstadt"),
// robuster Suchbegriff wenn WL und ÖBB Namen leicht anders schreiben
void keyword(const char *in, char *out, size_t n);

// UTF-8 -> Codepage 437 (Adafruit-GFX Standardfont), damit Umlaute am Display klappen
void utf8ToCp437(const char *in, char *out, size_t n);

// kürzt einen CP437-String auf maxChars Zeichen ("straße" -> "str.", "gasse" -> "g.")
void fitCp437(char *s, size_t maxChars);

} // namespace text

#endif
