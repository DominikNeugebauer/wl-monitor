#include "http_json.h"
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>

namespace http {

// Reader, der ein bereits verbrauchtes '{' wieder voranstellt
struct PrefixedReader {
    Stream &s;
    bool pending;
    int read() {
        if (pending) { pending = false; return '{'; }
        char c;
        return s.readBytes(&c, 1) == 1 ? (uint8_t)c : -1;
    }
    size_t readBytes(char *buf, size_t n) {
        if (n == 0) return 0;
        if (pending) {
            pending = false;
            buf[0] = '{';
            return 1 + s.readBytes(buf + 1, n - 1);
        }
        return s.readBytes(buf, n);
    }
};

bool getJson(const String &url, JsonDocument &doc, JsonDocument *filter, bool skipToBrace, String &error) {
    if (WiFi.status() != WL_CONNECTED) {
        error = "kein WLAN";
        return false;
    }

    // Host aus der URL holen und vorab auflösen -> genauere Fehlermeldung
    // (HTTPClient meldet sonst bei DNS-, TCP- UND TLS-Fehlern nur "connection refused")
    int hs = url.indexOf("://");
    String host = url.substring(hs < 0 ? 0 : hs + 3);
    int slash = host.indexOf('/');
    if (slash >= 0) host = host.substring(0, slash);
    IPAddress ip;
    if (!WiFi.hostByName(host.c_str(), ip) || ip == IPAddress(0, 0, 0, 0)) {
        error = "DNS: " + host + " nicht aufl\xC3\xB6sbar";
        return false;
    }

    WiFiClientSecure client;
    client.setInsecure();   // öffentliche Fahrplandaten, kein Zertifikats-Pinning nötig

    HTTPClient http;
    http.useHTTP10(true);   // kein chunked encoding -> Stream direkt parsebar
    http.setTimeout(12000);
    http.setConnectTimeout(8000);
    http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
    if (!http.begin(client, url)) {
        error = "URL ungültig";
        return false;
    }
    http.addHeader("Accept", "application/json, text/javascript, */*");
    http.setUserAgent("wl-monitor-esp32/1.0");

    int code = http.GET();
    if (code != HTTP_CODE_OK) {
        if (code > 0) {
            error = "HTTP " + String(code);
        } else {
            // Verbindungsfehler: IP + TLS-Fehler (mbedTLS) mit ausgeben
            char tls[100] = "";
            int tlsErr = client.lastError(tls, sizeof(tls));
            error = http.errorToString(code) + " (" + host + " = " + ip.toString();
            if (tlsErr) error += ", TLS " + String(tlsErr) + ": " + tls;
            error += ")";
        }
        http.end();
        return false;
    }

    // WL-Antworten sind tiefer als das Standardlimit (10) verschachtelt,
    // z.B. departure -> vehicle -> attributes. Das Limit gilt auch für weggefilterte Teile.
    const auto NESTING = DeserializationOption::NestingLimit(32);

    Stream &stream = http.getStream();
    stream.setTimeout(12000);
    DeserializationError err;
    if (skipToBrace) {
        if (!stream.find((char *)"{")) {
            error = "kein JSON in Antwort";
            http.end();
            return false;
        }
        PrefixedReader reader{stream, true};
        err = filter ? deserializeJson(doc, reader, DeserializationOption::Filter(*filter), NESTING)
                     : deserializeJson(doc, reader, NESTING);
    } else {
        err = filter ? deserializeJson(doc, stream, DeserializationOption::Filter(*filter), NESTING)
                     : deserializeJson(doc, stream, NESTING);
    }
    http.end();

    if (err) {
        error = String("JSON: ") + err.c_str();
        return false;
    }
    return true;
}

String urlEncode(const String &s) {
    static const char hex[] = "0123456789ABCDEF";
    String out;
    out.reserve(s.length() * 3);
    for (size_t i = 0; i < s.length(); i++) {
        uint8_t c = (uint8_t)s[i];
        if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') {
            out += (char)c;
        } else {
            out += '%';
            out += hex[c >> 4];
            out += hex[c & 0xF];
        }
    }
    return out;
}

} // namespace http
