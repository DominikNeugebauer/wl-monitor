#ifndef SETTINGS_H
#define SETTINGS_H

#include <Arduino.h>
#include <ArduinoJson.h>
#include "../transit/transit_types.h"

// ---------------------------------------------------------------------------
// Persistente Einstellungen im NVS (Preferences), überleben Neustart + Flashen
// ---------------------------------------------------------------------------
struct AppSettings {
    char          wifiSsid[33];
    char          wifiPass[65];
    MonitorConfig monitors[kMaxMonitors];
    uint8_t       nMonitors;
    uint8_t       brightness;   // 10..255
    bool          flip;         // Display um 180° drehen
};

namespace settings {

void load(AppSettings &s);
void saveWifi(const char *ssid, const char *pass);
void clearWifi();
void saveMonitors(const AppSettings &s);
void saveDisplay(const AppSettings &s);

// Standard-Konfiguration (Döbling: S45, 38, 35A, 10A)
void loadDefaultMonitors(AppSettings &s);

// JSON <-> Konfiguration (wird für NVS und die Web-API verwendet)
void monitorsToJson(const AppSettings &s, JsonArray arr);
// gibt false zurück wenn ein Eintrag ungültig ist
bool monitorsFromJson(JsonArrayConst arr, AppSettings &s, String *error);

} // namespace settings

#endif
