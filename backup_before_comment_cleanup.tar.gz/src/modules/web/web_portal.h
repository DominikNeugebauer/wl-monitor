#ifndef WEB_PORTAL_H
#define WEB_PORTAL_H

#include <Arduino.h>
#include <WebServer.h>
#include <ArduinoJson.h>
#include <functional>
#include "../net/wifi_manager.h"
#include "../settings/settings.h"
#include "../transit/transit_service.h"

// ---------------------------------------------------------------------------
// Web-Oberfläche + REST-API (Port 80)
//   /                 Single-Page-App (aus web/index.html, gzip im Flash)
//   /stops.txt        Haltestellenliste Wiener Linien (DIVA;Name)
//   /api/status       WLAN-/Systemstatus
//   /api/scan         WLAN-Netze in der Nähe
//   /api/wifi         POST {ssid, pass} -> verbinden + speichern
//   /api/wifi/forget  POST -> WLAN-Daten löschen
//   /api/config       GET/POST Linien + Display
//   /api/config/reset POST -> Standard-Linien
//   /api/departures   aktuelle Abfahrten (wie am Display)
//   /api/wl/lookup    ?diva=  Linien/Richtungen einer WL-Station
//   /api/oebb/search  ?q=     ÖBB-Stationssuche
//   /api/oebb/lines   ?id=    Linien/Ziele einer ÖBB-Station
//   /api/restart      POST
// ---------------------------------------------------------------------------
class WebPortal {
public:
    using Callback = std::function<void()>;

    void begin(WifiManager &wm, AppSettings &settings, TransitService &transit, Callback onDisplayChanged);
    void loop();

private:
    void sendJson(int code, JsonDocument &doc);
    void sendError(int code, const String &msg);
    bool parseBody(JsonDocument &doc);
    bool isOwnHost(const String &host);
    bool requireInternet();

    void handleStatus();
    void handleScan();
    void handleWifi();
    void handleForget();
    void handleGetConfig();
    void handlePostConfig();
    void handleResetConfig();
    void handleDepartures();
    void handleWlLookup();
    void handleOebbSearch();
    void handleOebbLines();
    void handleNotFound();

    WebServer       _server{80};
    WifiManager    *_wm = nullptr;
    AppSettings    *_settings = nullptr;
    TransitService *_transit = nullptr;
    Callback        _onDisplay;

    String   _scanCache = "[]";
    uint32_t _scanAt = 0;
    uint32_t _restartAt = 0;
};

#endif
