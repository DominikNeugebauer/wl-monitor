#include "wifi_manager.h"
#include "../logger/logger.h"
#include "../../config.h"
#include <ESPmDNS.h>

static void wlog(const String &s, LogLevel l = INFO) { Logger::getInstance()->log(s.c_str(), l); }

void WifiManager::begin(const char *ssid, const char *pass) {
    _ssid = ssid ? ssid : "";
    _pass = pass ? pass : "";

    uint8_t mac[6];
    WiFi.macAddress(mac);
    char buf[32];
    snprintf(buf, sizeof(buf), "%s%02X%02X", AP_SSID_PREFIX, mac[4], mac[5]);
    _apSsid = buf;

    WiFi.persistent(false);          // Zugangsdaten verwalten wir selbst im NVS
    WiFi.setHostname(APP_HOSTNAME);
    WiFi.setAutoReconnect(true);
    WiFi.onEvent([this](WiFiEvent_t, WiFiEventInfo_t info) {
        _lastReason = info.wifi_sta_disconnected.reason;
    }, ARDUINO_EVENT_WIFI_STA_DISCONNECTED);

    if (hasCredentials()) {
        WiFi.mode(WIFI_STA);
        connect(_ssid, _pass, false);
    } else {
        startAp();
    }
}

void WifiManager::connect(const String &ssid, const String &pass, bool fromPortal) {
    _pendingSsid = ssid;
    _pendingPass = pass;
    _fromPortal = fromPortal;
    _state = StaState::Connecting;
    _connectStart = millis();
    _lastRetry = millis();
    _lastReason = 0;

    wlog("WLAN: verbinde mit " + ssid);
    WiFi.mode(_apActive ? WIFI_AP_STA : WIFI_STA);
    // Stromsparmodus aus: sonst verschluckt der ESP eingehende Anfragen
    // (Web-Oberfläche lädt nicht / wl-monitor.local wird nicht gefunden)
    WiFi.setSleep(false);
    WiFi.disconnect(false);
    delay(50);
    WiFi.begin(ssid.c_str(), pass.c_str());
}

void WifiManager::forget() {
    _ssid = "";
    _pass = "";
    WiFi.disconnect(false);
    _state = StaState::Idle;
    startAp();
}

const char *WifiManager::stateName() const {
    switch (_state) {
        case StaState::Connecting: return "connecting";
        case StaState::Connected: return "connected";
        case StaState::Failed: return "failed";
        default: return "idle";
    }
}

void WifiManager::startAp() {
    if (_apActive) return;
    wlog("WLAN: starte Setup-AP " + _apSsid);
    WiFi.mode(WIFI_AP_STA);
    WiFi.softAPConfig(_apIp, _apIp, IPAddress(255, 255, 255, 0));
    const char *pw = strlen(AP_PASSWORD) >= 8 ? AP_PASSWORD : nullptr;
    WiFi.softAP(_apSsid.c_str(), pw);
    // Captive Portal: jede DNS-Anfrage zeigt auf uns
    _dns.setErrorReplyCode(DNSReplyCode::NoError);
    _dns.start(53, "*", _apIp);
    _apActive = true;
}

void WifiManager::stopAp() {
    if (!_apActive) return;
    wlog("WLAN: Setup-AP aus");
    _dns.stop();
    WiFi.softAPdisconnect(true);
    WiFi.mode(WIFI_STA);
    _apActive = false;
}

void WifiManager::onGotIp() {
    _state = StaState::Connected;
    _connectedSince = millis();
    wlog("WLAN: verbunden, IP " + WiFi.localIP().toString());

    if (_fromPortal || _ssid != _pendingSsid || _pass != _pendingPass) {
        if (_pendingSsid.length()) {
            _ssid = _pendingSsid;
            _pass = _pendingPass;
            if (_cb) _cb(_ssid, _pass); // -> im NVS speichern
        }
    }
    _fromPortal = false;

    // mDNS bei JEDER (Wieder-)Verbindung neu starten - nach einem WLAN-Abbruch
    // antwortet es sonst nicht mehr und wl-monitor.local ist weg
    if (_mdnsStarted) MDNS.end();
    _mdnsStarted = MDNS.begin(APP_HOSTNAME);
    if (_mdnsStarted) MDNS.addService("http", "tcp", 80);
    else wlog("mDNS konnte nicht gestartet werden", WARNING);
}

void WifiManager::loop() {
    if (_apActive) _dns.processNextRequest();

    const uint32_t now = millis();
    const bool up = WiFi.status() == WL_CONNECTED;

    switch (_state) {
        case StaState::Connecting: {
            if (up) { onGotIp(); break; }
            uint8_t r = _lastReason;
            bool authFail = (r == 15 || r == 202 || r == 204 || r == 2); // Passwort falsch
            bool notFound = (r == 201);
            uint32_t dt = now - _connectStart;
            if (dt > STA_CONNECT_TIMEOUT_MS || ((authFail || notFound) && dt > 6000)) {
                wlog("WLAN: Verbindung fehlgeschlagen (Grund " + String(r) + ")", WARNING);
                _state = StaState::Failed;
                _lostSince = _lostSince ? _lostSince : now;
                WiFi.disconnect(false); // AP-Kanal stabil halten
                if (!_apActive && (!hasCredentials() || _fromPortal || !_connectedSince)) startAp();
                _fromPortal = false;
                _lastRetry = now;
            }
            break;
        }
        case StaState::Connected:
            if (!up) {
                wlog("WLAN: Verbindung verloren", WARNING);
                _state = StaState::Idle;
                _lostSince = now;
                _lastRetry = now;
                break;
            }
            // nach erfolgreicher Einrichtung den Setup-AP noch kurz offen lassen,
            // damit das Handy die Erfolgsseite + IP anzeigen kann
            // (solange noch ein Handy verbunden ist max. 15 min, damit man direkt
            //  im Setup-WLAN auch gleich die Linien auswählen kann)
            if (_apActive && now - _connectedSince > AP_LINGER_MS &&
                (apClients() == 0 || now - _connectedSince > 15UL * 60UL * 1000UL))
                stopAp();
            break;

        case StaState::Idle:
        case StaState::Failed:
            if (up) { onGotIp(); break; }
            if (!hasCredentials()) {
                if (!_apActive) startAp();
                break;
            }
            // Heim-WLAN lange weg -> Setup-AP zusätzlich anbieten
            if (!_apActive && _lostSince && now - _lostSince > AP_FALLBACK_AFTER_MS) startAp();
            // periodisch neu versuchen - aber nicht, solange ein Handy am Setup-AP hängt
            // (Kanalwechsel beim Scannen würde dessen Verbindung stören)
            if (now - _lastRetry > STA_RETRY_INTERVAL_MS && apClients() == 0) {
                connect(_ssid, _pass, false);
            }
            break;
    }
}
