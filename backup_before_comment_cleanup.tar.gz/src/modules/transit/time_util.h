#ifndef TIME_UTIL_H
#define TIME_UTIL_H

#include <time.h>

namespace timeutil {

// POSIX-TZ für Wien (MEZ/MESZ)
static const char *const kTzVienna = "CET-1CEST,M3.5.0,M10.5.0/3";

// "2026-09-24T21:19:40.000+0200" -> UTC epoch (0 bei Fehler)
time_t parseIsoOffset(const char *s);

// "24.09.2026" + "21:27" (Lokalzeit Wien) -> UTC epoch (0 bei Fehler)
// Voraussetzung: TZ ist gesetzt (configTzTime / setenv+tzset)
time_t parseLocalDateTime(const char *date, const char *hhmm);

// true wenn die Systemzeit plausibel ist (NTP synchronisiert)
bool timeValid(time_t now);

} // namespace timeutil

#endif
