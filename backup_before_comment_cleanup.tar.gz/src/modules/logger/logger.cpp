#include "logger.h"
#include <Adafruit_ST7735.h>

// External reference to the tft object defined in your main file
extern Adafruit_ST7735 tft;

// Initialize static members
Logger* Logger::instance = nullptr;
LogMode Logger::mode = ONLY_SERIAL;
LogLevel Logger::level = INFO;

Logger::Logger(LogMode m, LogLevel l) {
    mode = m;
    level = l;
}

void Logger::init(LogMode m, LogLevel l) {
    if (instance == nullptr) {
        instance = new Logger(m, l);
    } else {
        mode = m;
        level = l;
    }
}

Logger* Logger::getInstance() {
    if (instance == nullptr) {
        // Fallback initialization if init() wasn't called
        instance = new Logger(ONLY_SERIAL, INFO);
    }
    return instance;
}

void Logger::log(const char *message, LogLevel msgLevel) {
    if (mode == NONE) return;

    // level filter: INFO = all, WARNING = warn+error, ERROR = only error
    if (msgLevel < level) return;

    // 1. Prepare Serial output with timestamp and level prefix
    String levelPrefix = "[INFO] ";
    if (msgLevel == WARNING) levelPrefix = "[WARN] ";
    if (msgLevel == ERROR)   levelPrefix = "[ERR ] ";

    String logLine = "[" + String(millis()) + "] " + levelPrefix + message;

    // 2. Handle Serial Output
    if (mode == ONLY_SERIAL || mode == SERIAL_AND_DISPLAY) {
        Serial.println(logLine);
    }

    // 3. Handle Display Output
    if (mode == ONLY_DISPLAY || mode == SERIAL_AND_DISPLAY) {
        // Change color based on severity
        if (msgLevel == ERROR) {
            tft.setTextColor(ST77XX_RED);
        } else if (msgLevel == WARNING) {
            tft.setTextColor(ST77XX_YELLOW);
        } else {
            tft.setTextColor(ST77XX_WHITE);
        }

        tft.println(message);
        
        // Reset to white for future non-logger drawing operations
        tft.setTextColor(ST77XX_WHITE);

        // Check for display overflow using cursor position
        if (tft.getCursorY() + 7 >= tft.height()) {  // 7 is approx font height
            tft.fillScreen(ST77XX_BLACK);
            tft.setCursor(0, 0);  // Reset cursor to top-left
        }
    }
}

void Logger::setMode(LogMode newMode) {
    mode = newMode;
    if (newMode != ONLY_DISPLAY && newMode != SERIAL_AND_DISPLAY) {
        tft.fillScreen(ST77XX_BLACK);
        tft.setCursor(0, 0);
    }
}