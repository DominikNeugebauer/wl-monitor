#ifndef TRANSIT_TYPES_H
#define TRANSIT_TYPES_H

#include <stdint.h>
#include <stddef.h>
#include <time.h>

// ---------------------------------------------------------------------------
// Datenmodell für Abfahrtsmonitor (plattformunabhängig -> auch am PC testbar)
// ---------------------------------------------------------------------------

enum class Source : uint8_t { WL = 0, OEBB = 1 };

enum class VehicleKind : uint8_t { Tram, Bus, NightBus, Metro, SBahn, Train, Other };

// Ein vom User konfigurierter Eintrag = eine Zeile am Display
struct MonitorConfig {
    Source   src;
    uint32_t stop;          // WL: RBL (StopID), ÖBB: evaId der Station
    uint32_t dir;           // nur ÖBB: evaId einer Station "in Richtung" (0 = egal)
    char     line[8];       // z.B. "38", "35A", "S45"
    char     dest[24];      // ÖBB: Filter auf Zielname (Teilstring)
                            // WL:  Ziel ("Schottentor") - nur für den ÖBB-Fallback
    char     stopName[32];  // nur für Anzeige in der Web-UI
};

static const int kMaxDepsPerRow = 4;
static const int kMaxMonitors   = 10;

struct Departure {
    time_t planned;     // Plan-Abfahrt (UTC epoch)
    time_t real;        // Echtzeit-Prognose (== planned wenn keine Echtzeit)
    bool   realtime;    // true = Echtzeitdaten vorhanden
    bool   cancelled;   // fällt aus
};

struct Row {
    char        line[8];
    char        dest[32];
    char        stopName[32];
    VehicleKind kind;
    Source      src;
    Departure   deps[kMaxDepsPerRow];
    uint8_t     nDeps;
    bool        ok;         // letzter Abruf erfolgreich
    bool        viaFallback;// WL nicht erreichbar -> Daten kommen von der ÖBB-Auskunft
    time_t      fetchedAt;  // Zeitpunkt des letzten erfolgreichen Abrufs
};

#endif
